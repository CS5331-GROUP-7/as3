<h1>Case 17</h1>
<font color=red>[Note to student] You are advised to clear your cookies (cookies for case 17) if you did not log out properly from this case.  </font>
<br/><br/>
<a href="login.php">Login</a><br/>
<a href="register.php">Register</a>