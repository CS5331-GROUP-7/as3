<h1>Case 32</h1>
<h2></h2>

<?php 
		$redirect_url = 'case32-1.php';
		header("Location: " . $redirect_url); 
?>

<div id="demo">The flag is v6xAT3M7Ab67RDy</div>