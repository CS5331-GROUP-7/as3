<?php 
	phpinfo(); 
?>
