<h1>Case 23</h1>
<font color=red>[Note to student] You are advised to clear your cookies (cookies for case 23 if it exists) before you start this case.  </font>

<br/>
<a href="login.php">Login</a><br/>
<a href="register.php">Register</a>