<?php
echo "The flag is MPGKgf7sHSmftp7";
?>
