<p>
	PHP（全称：PHP：Hypertext Preprocessor，即“PHP：超文本预处理器”）是一种开源的通用计算机脚本语言，尤其适用于网络开发并可嵌入HTML中使用。PHP的语法借鉴吸收C语言、Java和Perl等流行计算机语言的特点，易于一般程序员学习。PHP的主要目标是允许网络开发人员快速编写动态页面，但PHP也被用于其他很多领域。[1]
PHP最初是由勒多夫在1995年开始开发的。而現在PHP的標準由PHP Group和開放原始碼社群維護。PHP以PHP License作為許可協議，不過因為這個協議限制了PHP名稱的使用，所以和開放原始碼許可協議GPL不相容。[2]
PHP的應用範圍相當廣泛，尤其是在網頁程式的開發上。一般來說PHP大多執行在網頁伺服器上，透過執行PHP程式碼來產生使用者瀏覽的網頁。PHP可以在多數的伺服器和作業系統上執行，而且使用PHP完全是免費的。根據2007年4月的統計資料，PHP已經被安裝在超過2000萬個網站和100萬台伺服器上[3]。
PHP on Microsoft Windows PHP 5.5.8 是由 Microsoft VC11 所編譯；其將不支持舊有的 Windows XP 系統。
	
</p>

<a href="case18.php">back</a>
